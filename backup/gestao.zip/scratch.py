from sympy.solvers import solve
from sympy import Symbol, symbols
from sympy import summation
from sympy import Array 


k, N, r, Val = symbols("k, N, r, Val")
r = 0.08
N = 3
# listaCashFlow = [int(x)  for in input.split(" ")]

listaCashFlow = Array([-900_000, -950_000, 0, 2_150_000])
eq = summation(listaCashFlow[k]/((1+r)**k), (k,0,N))

print(solve(eq-Val, Val))

# val = sum(c(k-1)/(1+r)**k  ,(k,n))

# quero uma tabela de cashflows

# posso pedir os valores a toa com espacos
#     -1000 95.42 90.7  950.22
#     listaCashFlow = [int(x)  for in input.split(" ")]